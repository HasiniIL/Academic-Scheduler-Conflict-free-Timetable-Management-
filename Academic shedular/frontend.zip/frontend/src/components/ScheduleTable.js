

/*
import React from 'react';
import { EditIcon, TrashIcon, AlertCircleIcon } from 'lucide-react';

export const ScheduleTable = ({
  assignments,
  onEdit,
  onDeleteRequest,
  lecturers,
}) => {
  // Function to get lecturer name
  const getLecturerName = (lecturerId) => {
    const lecturer = lecturers.find((l) => l._id === lecturerId);
    return lecturer ? lecturer.name : 'Unknown';
  };

  // Function to get lecturer expertise
  const getLecturerExpertise = (lecturerId) => {
    const lecturer = lecturers.find((l) => l._id === lecturerId);
    return lecturer ? lecturer.expertise : 'Unknown Expertise';
  };

  const getTimeSlot = (timeSlot) => {
    return timeSlot ? `${timeSlot.day} ${timeSlot.startTime} - ${timeSlot.endTime}` : 'Unknown';
  };

  return (
    <div className="overflow-x-auto">
      {assignments.length > 0 ? (
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-blue-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-blue-600 uppercase tracking-wider">Lecturer</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-blue-600 uppercase tracking-wider">Expertise</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-blue-600 uppercase tracking-wider">Time Slot</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-blue-600 uppercase tracking-wider">Notes</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-blue-600 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {assignments.map((assignment) => (
              <tr key={assignment._id} className="hover:bg-blue-50 transition-colors duration-150">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="h-8 w-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mr-3">
                      <span className="font-medium text-sm">
                        {getLecturerName(assignment.lecturer)?.charAt(0)}
                      </span>
                    </div>
                    <div className="text-sm font-medium text-gray-900">
                      {getLecturerName(assignment.lecturer)}
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {getLecturerExpertise(assignment.lecturer)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {getTimeSlot(assignment.timeSlot)}
                </td>
                <td className="px-6 py-4 text-sm text-gray-500 max-w-xs truncate">
                  {assignment.notes || '-'}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <button
                    onClick={() => onEdit(assignment)}
                    className="inline-flex items-center text-blue-600 hover:text-blue-800 mr-4"
                  >
                    <EditIcon className="h-4 w-4" />
                    <span className="ml-2">Edit</span>
                  </button>
                  <button
                    onClick={() => onDeleteRequest(assignment._id)}
                    className="inline-flex items-center text-red-600 hover:text-red-800"
                  >
                    <TrashIcon className="h-4 w-4" />
                    <span className="ml-2">Delete</span>
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <div className="flex flex-col items-center justify-center py-12 text-gray-500">
          <AlertCircleIcon className="h-12 w-12 mb-4 text-blue-400" />
          <h3 className="text-lg font-medium mb-1">No assignments found</h3>
          <p className="text-sm">Create a new assignment to get started.</p>
        </div>
      )}
    </div>
  );
};

// ScheduleTable.jsx
// src/components/ScheduleTable.js*/

import React from 'react';
import { EditIcon, TrashIcon, AlertCircleIcon } from 'lucide-react';

export const ScheduleTable = ({
  assignments,
  onEdit,
  onDeleteRequest,
  lecturers,
}) => {
  // Get name from populated object or fallback to lookup
  const getLecturerName = (lecturerData) => {
    if (typeof lecturerData === 'object' && lecturerData !== null && lecturerData.name) {
      return lecturerData.name;
    }
    const lecturer = lecturers.find((l) => l._id === lecturerData);
    return lecturer ? lecturer.name : 'Unknown';
  };

  // Get expertise from populated object or fallback to lookup
  const getLecturerExpertise = (lecturerData) => {
    if (typeof lecturerData === 'object' && lecturerData !== null && lecturerData.expertise) {
      return lecturerData.expertise;
    }
    const lecturer = lecturers.find((l) => l._id === lecturerData);
    return lecturer ? lecturer.expertise : 'Unknown Expertise';
  };

  const getTimeSlot = (timeSlot) => {
    return timeSlot ? `${timeSlot.day} ${timeSlot.startTime} - ${timeSlot.endTime}` : 'Unknown';
  };

  return (
    <div className="overflow-x-auto">
      {assignments.length > 0 ? (
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-blue-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-blue-600 uppercase tracking-wider">Lecturer</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-blue-600 uppercase tracking-wider">Expertise</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-blue-600 uppercase tracking-wider">Time Slot</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-blue-600 uppercase tracking-wider">Notes</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-blue-600 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {assignments.map((assignment) => (
              <tr key={assignment._id} className="hover:bg-blue-50 transition-colors duration-150">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="h-8 w-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mr-3">
                      <span className="font-medium text-sm">
                        {getLecturerName(assignment.lecturer)?.charAt(0)}
                      </span>
                    </div>
                    <div className="text-sm font-medium text-gray-900">
                      {getLecturerName(assignment.lecturer)}
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {getLecturerExpertise(assignment.lecturer)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {getTimeSlot(assignment.timeSlot)}
                </td>
                <td className="px-6 py-4 text-sm text-gray-500 max-w-xs truncate">
                  {assignment.notes || '-'}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <button
                    onClick={() => onEdit(assignment)}
                    className="inline-flex items-center text-blue-600 hover:text-blue-800 mr-4"
                  >
                    <EditIcon className="h-4 w-4" />
                    <span className="ml-2">Edit</span>
                  </button>
                  <button
                    onClick={() => onDeleteRequest(assignment._id)}
                    className="inline-flex items-center text-red-600 hover:text-red-800"
                  >
                    <TrashIcon className="h-4 w-4" />
                    <span className="ml-2">Delete</span>
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <div className="flex flex-col items-center justify-center py-12 text-gray-500">
          <AlertCircleIcon className="h-12 w-12 mb-4 text-blue-400" />
          <h3 className="text-lg font-medium mb-1">No assignments found</h3>
          <p className="text-sm">Create a new assignment to get started.</p>
        </div>
      )}
    </div>
  );
};
