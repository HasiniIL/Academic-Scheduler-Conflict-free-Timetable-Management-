/*
import React, { useState } from 'react';
import { DownloadIcon, FilterIcon } from 'lucide-react';
import jsPDF from 'jspdf';
import { mockCourses, mockRooms } from '../../data/mockData';

const TimetableView = ({ assignments = [], lecturerId }) => {
  const [dayFilter, setDayFilter] = useState('all');
  const [courseFilter, setCourseFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');

  // Filter assignments by lecturerId
  const lecturerSchedule = assignments.filter(
    (assignment) => assignment.lecturerId === lecturerId
  );

  // Mock days for filtering
  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

  // Mock courses for filtering
  const courses = mockCourses.map((course) => ({
    id: course.id,
    name: course.name,
  }));

  // Mock types for filtering
  const types = ['Lecture', 'Lab', 'Tutorial'];

  // Filter schedule by day, course, and type
  const filteredSchedule = lecturerSchedule.filter((item) => {
    const matchesDay = dayFilter === 'all' || item.day === dayFilter;
    const matchesCourse = courseFilter === 'all' || item.courseId === courseFilter;
    const matchesType = typeFilter === 'all' || item.type === typeFilter;
    return matchesDay && matchesCourse && matchesType;
  });

  // Helper function to get course name
  const getCourseName = (courseId) => {
    const course = mockCourses.find((c) => c.id === courseId);
    return course ? course.name : 'Unknown';
  };

  // Helper function to get room name
  const getRoomName = (roomId) => {
    const room = mockRooms.find((r) => r.id === roomId);
    return room ? room.name : 'Unknown';
  };

  // Download PDF functionality
  const downloadPDF = () => {
    const doc = new jsPDF();
    // Add title
    doc.setFontSize(18);
    doc.text('Lecturer Timetable Schedule', 14, 22);
    // Add lecturer info
    doc.setFontSize(12);
    doc.text(`Lecturer ID: ${lecturerId}`, 14, 32);
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 14, 38);
    // Add schedule items
    let yPos = 50;
    // Headers
    doc.setFont(undefined, 'bold');
    doc.text('Course', 14, yPos);
    doc.text('Day', 80, yPos);
    doc.text('Time', 110, yPos);
    doc.text('Room', 150, yPos);
    doc.text('Type', 180, yPos);
    doc.setFont(undefined, 'normal');
    yPos += 10;
    // Content
    filteredSchedule.forEach((item) => {
      if (yPos > 270) {
        // Add new page if near bottom
        doc.addPage();
        yPos = 20;
      }
      doc.text(getCourseName(item.courseId), 14, yPos);
      doc.text(item.day, 80, yPos);
      doc.text(`${item.startTime}-${item.endTime}`, 110, yPos);
      doc.text(getRoomName(item.roomId), 150, yPos);
      doc.text(item.type, 180, yPos);
      yPos += 10;
    });
    doc.save('lecturer-timetable.pdf');
  };

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">My Timetable</h2>
          <p className="text-gray-600">View your weekly teaching schedule</p>
        </div>
        <div className="flex items-center space-x-3 mt-4 md:mt-0">
          <div className="relative">
            <select
              className="appearance-none bg-white border border-gray-300 rounded-md pl-10 pr-4 py-2 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={dayFilter}
              onChange={(e) => setDayFilter(e.target.value)}
            >
              <option value="all">All Days</option>
              {days.map((day) => (
                <option key={day} value={day}>
                  {day}
                </option>
              ))}
            </select>
            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center px-3 text-gray-500">
              <FilterIcon size={16} />
            </div>
          </div>
          <div className="relative">
            <select
              className="appearance-none bg-white border border-gray-300 rounded-md pl-10 pr-4 py-2 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={courseFilter}
              onChange={(e) => setCourseFilter(e.target.value)}
            >
              <option value="all">All Courses</option>
              {courses.map((course) => (
                <option key={course.id} value={course.id}>
                  {course.name}
                </option>
              ))}
            </select>
            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center px-3 text-gray-500">
              <FilterIcon size={16} />
            </div>
          </div>
          <div className="relative">
            <select
              className="appearance-none bg-white border border-gray-300 rounded-md pl-10 pr-4 py-2 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
            >
              <option value="all">All Types</option>
              {types.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>
            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center px-3 text-gray-500">
              <FilterIcon size={16} />
            </div>
          </div>
          <button
            onClick={downloadPDF}
            className="flex items-center space-x-2 bg-blue-700 hover:bg-blue-800 text-white font-medium py-2 px-4 rounded-md transition-colors"
          >
            <DownloadIcon size={18} />
            <span>Download PDF</span>
          </button>
        </div>
      </div>
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-blue-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">
                  Course
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">
                  Day
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">
                  Time
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">
                  Room
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">
                  Type
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredSchedule.length > 0 ? (
                filteredSchedule.map((schedule) => (
                  <tr key={schedule.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {getCourseName(schedule.courseId)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {schedule.day}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {schedule.startTime} - {schedule.endTime}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {getRoomName(schedule.roomId)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span
                        className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${schedule.type === 'Lecture' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'}`}
                      >
                        {schedule.type}
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td
                    colSpan={5}
                    className="px-6 py-4 text-center text-sm text-gray-500"
                  >
                    No schedule found for the selected filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default TimetableView;*/
/*
import React, { useState } from 'react';
import { DownloadIcon, FilterIcon } from 'lucide-react';
import jsPDF from 'jspdf';

const TimetableView = ({ assignments = [], lecturerId }) => {
  const [slotFilter, setSlotFilter] = useState('all');
  const [expertiseFilter, setExpertiseFilter] = useState('all');

  const lecturerSchedule = assignments.filter(
    (assignment) => assignment.lecturerId === lecturerId
  );

  const expertiseOptions = [...new Set(lecturerSchedule.map(item => item.expertise))];
  const timeSlots = [...new Set(lecturerSchedule.map(item => item.timeSlot))];

  const filteredSchedule = lecturerSchedule.filter((item) => {
    const matchesExpertise = expertiseFilter === 'all' || item.expertise === expertiseFilter;
    const matchesSlot = slotFilter === 'all' || item.timeSlot === slotFilter;
    return matchesExpertise && matchesSlot;
  });

  const downloadPDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(18);
    doc.text('Lecturer Timetable Schedule', 14, 22);
    doc.setFontSize(12);
    doc.text(`Lecturer ID: ${lecturerId}`, 14, 32);
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 14, 38);

    let yPos = 50;
    doc.setFont(undefined, 'bold');
    doc.text('Lecturer', 14, yPos);
    doc.text('Expertise', 60, yPos);
    doc.text('Time Slot', 110, yPos);
    doc.text('Notes', 160, yPos);
    doc.setFont(undefined, 'normal');
    yPos += 10;

    filteredSchedule.forEach((item) => {
      if (yPos > 270) {
        doc.addPage();
        yPos = 20;
      }
      doc.text(item.lecturerName || 'N/A', 14, yPos);
      doc.text(item.expertise || 'N/A', 60, yPos);
      doc.text(item.timeSlot || 'N/A', 110, yPos);
      doc.text(item.notes || 'N/A', 160, yPos);
      yPos += 10;
    });

    doc.save('lecturer-timetable.pdf');
  };

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">My Timetable</h2>
          <p className="text-gray-600">View your weekly teaching schedule</p>
        </div>
        <div className="flex items-center space-x-3 mt-4 md:mt-0">
          <div className="relative">
            <select
              className="appearance-none bg-white border border-gray-300 rounded-md pl-10 pr-4 py-2 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={expertiseFilter}
              onChange={(e) => setExpertiseFilter(e.target.value)}
            >
              <option value="all">All Expertise</option>
              {expertiseOptions.map((exp) => (
                <option key={exp} value={exp}>{exp}</option>
              ))}
            </select>
            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center px-3 text-gray-500">
              <FilterIcon size={16} />
            </div>
          </div>
          <div className="relative">
            <select
              className="appearance-none bg-white border border-gray-300 rounded-md pl-10 pr-4 py-2 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={slotFilter}
              onChange={(e) => setSlotFilter(e.target.value)}
            >
              <option value="all">All Time Slots</option>
              {timeSlots.map((slot) => (
                <option key={slot} value={slot}>{slot}</option>
              ))}
            </select>
            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center px-3 text-gray-500">
              <FilterIcon size={16} />
            </div>
          </div>
          <button
            onClick={downloadPDF}
            className="flex items-center space-x-2 bg-blue-700 hover:bg-blue-800 text-white font-medium py-2 px-4 rounded-md transition-colors"
          >
            <DownloadIcon size={18} />
            <span>Download PDF</span>
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-blue-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">Lecturer</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">Expertise</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">Time Slot</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">Notes</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredSchedule.length > 0 ? (
                filteredSchedule.map((schedule) => (
                  <tr key={schedule.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{schedule.lecturerName}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{schedule.expertise}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{schedule.timeSlot}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{schedule.notes}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={4} className="px-6 py-4 text-center text-sm text-gray-500">
                    No schedule found for the selected filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default TimetableView;*/

/*
import React, { useState, useEffect } from 'react';
import { DownloadIcon, FilterIcon } from 'lucide-react';
import jsPDF from 'jspdf';
import axios from 'axios';
import { mockCourses, mockRooms } from '../../data/mockData';

const TimetableView = ({ lecturerId }) => {
  const [assignments, setAssignments] = useState([]);
  const [dayFilter, setDayFilter] = useState('all');
  const [courseFilter, setCourseFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');

  // Fetch lecturer's schedule from the backend
  useEffect(() => {
    const fetchLecturerSchedule = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/api/schedules/lecturer/${lecturerId}`);
        setAssignments(response.data);
      } catch (error) {
        console.error('Failed to fetch lecturer schedule', error);
      }
    };

    if (lecturerId) {
      fetchLecturerSchedule();
    }
  }, [lecturerId]);

  // Mock days for filtering
  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

  // Mock courses for filtering
  const courses = mockCourses.map((course) => ({
    id: course.id,
    name: course.name,
  }));

  // Mock types for filtering
  const types = ['Lecture', 'Lab', 'Tutorial'];

  // Filter schedule by day, course, and type
  const filteredSchedule = assignments.filter((item) => {
    const matchesDay = dayFilter === 'all' || item.day === dayFilter;
    const matchesCourse = courseFilter === 'all' || item.courseId === courseFilter;
    const matchesType = typeFilter === 'all' || item.type === typeFilter;
    return matchesDay && matchesCourse && matchesType;
  });

  // Helper function to get course name
  const getCourseName = (courseId) => {
    const course = mockCourses.find((c) => c.id === courseId);
    return course ? course.name : 'Unknown';
  };

  // Helper function to get room name
  const getRoomName = (roomId) => {
    const room = mockRooms.find((r) => r.id === roomId);
    return room ? room.name : 'Unknown';
  };

  // Download PDF functionality
  const downloadPDF = () => {
    const doc = new jsPDF();
    // Add title
    doc.setFontSize(18);
    doc.text('Lecturer Timetable Schedule', 14, 22);
    // Add lecturer info
    doc.setFontSize(12);
    doc.text(`Lecturer ID: ${lecturerId}`, 14, 32);
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 14, 38);
    // Add schedule items
    let yPos = 50;
    // Headers
    doc.setFont(undefined, 'bold');
    doc.text('Course', 14, yPos);
    doc.text('Day', 80, yPos);
    doc.text('Time', 110, yPos);
    doc.text('Room', 150, yPos);
    doc.text('Type', 180, yPos);
    doc.setFont(undefined, 'normal');
    yPos += 10;
    // Content
    filteredSchedule.forEach((item) => {
      if (yPos > 270) {
        // Add new page if near bottom
        doc.addPage();
        yPos = 20;
      }
      doc.text(getCourseName(item.courseId), 14, yPos);
      doc.text(item.day, 80, yPos);
      doc.text(`${item.startTime}-${item.endTime}`, 110, yPos);
      doc.text(getRoomName(item.roomId), 150, yPos);
      doc.text(item.type, 180, yPos);
      yPos += 10;
    });
    doc.save('lecturer-timetable.pdf');
  };

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">My Timetable</h2>
          <p className="text-gray-600">View your weekly teaching schedule</p>
        </div>
        <div className="flex items-center space-x-3 mt-4 md:mt-0">
          <div className="relative">
            <select
              className="appearance-none bg-white border border-gray-300 rounded-md pl-10 pr-4 py-2 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={dayFilter}
              onChange={(e) => setDayFilter(e.target.value)}
            >
              <option value="all">All Days</option>
              {days.map((day) => (
                <option key={day} value={day}>
                  {day}
                </option>
              ))}
            </select>
            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center px-3 text-gray-500">
              <FilterIcon size={16} />
            </div>
          </div>
          <div className="relative">
            <select
              className="appearance-none bg-white border border-gray-300 rounded-md pl-10 pr-4 py-2 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={courseFilter}
              onChange={(e) => setCourseFilter(e.target.value)}
            >
              <option value="all">All Courses</option>
              {courses.map((course) => (
                <option key={course.id} value={course.id}>
                  {course.name}
                </option>
              ))}
            </select>
            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center px-3 text-gray-500">
              <FilterIcon size={16} />
            </div>
          </div>
          <div className="relative">
            <select
              className="appearance-none bg-white border border-gray-300 rounded-md pl-10 pr-4 py-2 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
            >
              <option value="all">All Types</option>
              {types.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>
            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center px-3 text-gray-500">
              <FilterIcon size={16} />
            </div>
          </div>
          <button
            onClick={downloadPDF}
            className="flex items-center space-x-2 bg-blue-700 hover:bg-blue-800 text-white font-medium py-2 px-4 rounded-md transition-colors"
          >
            <DownloadIcon size={18} />
            <span>Download PDF</span>
          </button>
        </div>
      </div>
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-blue-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">
                  Lecturer
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">
                  Expertise
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">
                  Time Slot
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">
                  Notes
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredSchedule.length > 0 ? (
                filteredSchedule.map((schedule) => (
                  <tr key={schedule._id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {schedule.lecturer.name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {schedule.lecturer.expertise}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {schedule.timeSlot}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {schedule.notes}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="4" className="px-6 py-4 text-center text-sm text-gray-500">
                    No schedules available.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default TimetableView;

*/

/*
import React, { useState, useEffect } from 'react';
import { DownloadIcon, FilterIcon } from 'lucide-react';
import jsPDF from 'jspdf';

// Mock data
const mockCourses = [
  { id: 'PSY101', name: 'Intro to Psychology' },
  { id: 'PSY202', name: 'Cognitive Behavior' },
];

const mockRooms = [
  { id: 'A101', name: 'Room A101' },
  { id: 'B202', name: 'Room B202' },
];

const TimetableView = ({ lecturerId }) => {
  const [assignments, setAssignments] = useState([]);
  const [dayFilter, setDayFilter] = useState('all');
  const [courseFilter, setCourseFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');

  // Hardcoded schedule data
  useEffect(() => {
    const mockSchedule = [
      {
        _id: '1',
        lecturer: {
          name: 'Prof. Sofia Alvarez',
          expertise: 'Psychology',
        },
        day: 'Monday',
        courseId: 'PSY101',
        timeSlot: '10:00 AM - 12:00 PM',
        startTime: '10:00 AM',
        endTime: '12:00 PM',
        roomId: 'A101',
        type: 'Lecture',
        notes: 'Bring case studies',
      },
      {
        _id: '2',
        lecturer: {
          name: 'Prof. Sofia Alvarez',
          expertise: 'Psychology',
        },
        day: 'Wednesday',
        courseId: 'PSY202',
        timeSlot: '1:00 PM - 3:00 PM',
        startTime: '1:00 PM',
        endTime: '3:00 PM',
        roomId: 'B202',
        type: 'Seminar',
        notes: '',
      },
    ];

    setAssignments(mockSchedule);
  }, []);

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  const types = ['Lecture', 'Lab', 'Seminar'];

  const filteredSchedule = assignments.filter((item) => {
    const matchesDay = dayFilter === 'all' || item.day === dayFilter;
    const matchesCourse = courseFilter === 'all' || item.courseId === courseFilter;
    const matchesType = typeFilter === 'all' || item.type === typeFilter;
    return matchesDay && matchesCourse && matchesType;
  });

  const getCourseName = (courseId) => {
    const course = mockCourses.find((c) => c.id === courseId);
    return course ? course.name : 'Unknown';
  };

  const getRoomName = (roomId) => {
    const room = mockRooms.find((r) => r.id === roomId);
    return room ? room.name : 'Unknown';
  };

  const downloadPDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(18);
    doc.text('Lecturer Timetable Schedule', 14, 22);
    doc.setFontSize(12);
    doc.text(`Lecturer ID: ${lecturerId}`, 14, 32);
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 14, 38);

    let yPos = 50;
    doc.setFont(undefined, 'bold');
    doc.text('Course', 14, yPos);
    doc.text('Day', 80, yPos);
    doc.text('Time', 110, yPos);
    doc.text('Room', 150, yPos);
    doc.text('Type', 180, yPos);
    doc.setFont(undefined, 'normal');
    yPos += 10;

    filteredSchedule.forEach((item) => {
      if (yPos > 270) {
        doc.addPage();
        yPos = 20;
      }
      doc.text(getCourseName(item.courseId), 14, yPos);
      doc.text(item.day, 80, yPos);
      doc.text(`${item.startTime}-${item.endTime}`, 110, yPos);
      doc.text(getRoomName(item.roomId), 150, yPos);
      doc.text(item.type, 180, yPos);
      yPos += 10;
    });

    doc.save('lecturer-timetable.pdf');
  };

  return (
    <div className="p-4">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">My Timetable</h2>
          <p className="text-gray-600">View your weekly teaching schedule</p>
        </div>
        <div className="flex items-center space-x-3 mt-4 md:mt-0">
         
          {[{ label: 'Day', options: days, value: dayFilter, setter: setDayFilter },
            { label: 'Course', options: mockCourses.map(c => ({ id: c.id, name: c.name })), value: courseFilter, setter: setCourseFilter },
            { label: 'Type', options: types, value: typeFilter, setter: setTypeFilter }]
            .map(({ label, options, value, setter }, index) => (
              <div className="relative" key={index}>
                <select
                  className="appearance-none bg-white border border-gray-300 rounded-md pl-10 pr-4 py-2 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={value}
                  onChange={(e) => setter(e.target.value)}
                >
                  <option value="all">All {label}s</option>
                  {options.map((opt) => (
                    <option key={opt.id || opt} value={opt.id || opt}>
                      {opt.name || opt}
                    </option>
                  ))}
                </select>
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center px-3 text-gray-500">
                  <FilterIcon size={16} />
                </div>
              </div>
            ))}
         
            
          <button
            onClick={downloadPDF}
            className="flex items-center space-x-2 bg-blue-700 hover:bg-blue-800 text-white font-medium py-2 px-4 rounded-md transition-colors"
          >
            <DownloadIcon size={18} />
            <span>Download PDF</span>
          </button>
        </div>
      </div>

      
      
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-blue-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">Lecturer</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">Expertise</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">Time Slot</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">Notes</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredSchedule.length > 0 ? (
                filteredSchedule.map((schedule) => (
                  <tr key={schedule._id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{schedule.lecturer.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{schedule.lecturer.expertise}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{schedule.timeSlot}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{schedule.notes}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="4" className="px-6 py-4 text-center text-sm text-gray-500">No schedules available.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default TimetableView;

*/
/*
import React, { useState, useEffect } from 'react';
import { DownloadIcon, FilterIcon } from 'lucide-react';
import jsPDF from 'jspdf';

const mockCourses = [
  { id: 'PSY101', name: 'Intro to Psychology' },
  { id: 'PSY202', name: 'Cognitive Behavior' },
  { id: 'PSY301', name: 'Social Psychology' },
];

const mockRooms = [
  { id: 'A101', name: 'Room A101' },
  { id: 'B202', name: 'Room B202' },
  { id: 'C303', name: 'Room C303' },
];

const TimetableView = ({ lecturerId }) => {
  const [assignments, setAssignments] = useState([]);
  const [dayFilter, setDayFilter] = useState('all');
  const [courseFilter, setCourseFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');

  useEffect(() => {
    const mockSchedule = [
      {
        _id: '1',
        lecturer: { name: 'Prof. Sofia Alvarez', expertise: 'Psychology' },
        day: 'Monday',
        courseId: 'PSY101',
        timeSlot: '10:00 AM - 12:00 PM',
        startTime: '10:00 AM',
        endTime: '12:00 PM',
        roomId: 'A101',
        type: 'Lecture',
        notes: 'Bring case studies',
      },
      {
        _id: '2',
        lecturer: { name: 'Prof. Sofia Alvarez', expertise: 'Psychology' },
        day: 'Wednesday',
        courseId: 'PSY202',
        timeSlot: '1:00 PM - 3:00 PM',
        startTime: '1:00 PM',
        endTime: '3:00 PM',
        roomId: 'B202',
        type: 'Seminar',
        notes: '',
      },
    ];
    setAssignments(mockSchedule);
  }, []);

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  const types = ['Lecture', 'Lab', 'Seminar'];

  const filteredSchedule = assignments.filter((item) => {
    const matchesDay = dayFilter === 'all' || item.day === dayFilter;
    const matchesCourse = courseFilter === 'all' || item.courseId === courseFilter;
    const matchesType = typeFilter === 'all' || item.type === typeFilter;
    return matchesDay && matchesCourse && matchesType;
  });

  const sortedSchedule = [...filteredSchedule].sort((a, b) => {
    const dayOrder = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    return dayOrder.indexOf(a.day) - dayOrder.indexOf(b.day) || a.startTime.localeCompare(b.startTime);
  });

  const getCourseName = (courseId) => {
    const course = mockCourses.find((c) => c.id === courseId);
    return course ? course.name : 'Unknown';
  };

  const getRoomName = (roomId) => {
    const room = mockRooms.find((r) => r.id === roomId);
    return room ? room.name : 'Unknown';
  };

  const downloadPDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(18);
    doc.text('Lecturer Timetable Schedule', 14, 22);
    doc.setFontSize(12);
    doc.text(`Lecturer ID: ${lecturerId}`, 14, 32);
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 14, 38);

    let yPos = 50;
    doc.setFont(undefined, 'bold');
    doc.text('Course', 14, yPos);
    doc.text('Day', 60, yPos);
    doc.text('Time', 90, yPos);
    doc.text('Room', 130, yPos);
    doc.text('Type', 160, yPos);
    doc.setFont(undefined, 'normal');
    yPos += 10;

    sortedSchedule.forEach((item) => {
      if (yPos > 270) {
        doc.addPage();
        yPos = 20;
      }
      doc.text(getCourseName(item.courseId), 14, yPos);
      doc.text(item.day, 60, yPos);
      doc.text(`${item.startTime}-${item.endTime}`, 90, yPos);
      doc.text(getRoomName(item.roomId), 130, yPos);
      doc.text(item.type, 160, yPos);
      yPos += 10;
    });

    doc.save('lecturer-timetable.pdf');
  };

  return (
    <div className="p-4">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">My Timetable</h2>
          <p className="text-gray-600">View your weekly teaching schedule</p>
        </div>
        <div className="flex items-center space-x-3 mt-4 md:mt-0 flex-wrap gap-2">
          {[{ label: 'Day', options: days, value: dayFilter, setter: setDayFilter },
            { label: 'Course', options: mockCourses.map(c => ({ id: c.id, name: c.name })), value: courseFilter, setter: setCourseFilter },
            { label: 'Type', options: types, value: typeFilter, setter: setTypeFilter }]
            .map(({ label, options, value, setter }, index) => (
              <div className="relative" key={index}>
                <select
                  className="appearance-none bg-white border border-gray-300 rounded-md pl-10 pr-4 py-2 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={value}
                  onChange={(e) => setter(e.target.value)}
                >
                  <option value="all">All {label}s</option>
                  {options.map((opt) => (
                    <option key={opt.id || opt} value={opt.id || opt}>
                      {opt.name || opt}
                    </option>
                  ))}
                </select>
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center px-3 text-gray-500">
                  <FilterIcon size={16} />
                </div>
              </div>
            ))}
          <button
            onClick={() => {
              setDayFilter('all');
              setCourseFilter('all');
              setTypeFilter('all');
            }}
            className="text-sm text-gray-600 hover:underline"
          >
            Clear Filters
          </button>
          <button
            onClick={downloadPDF}
            className="flex items-center space-x-2 bg-blue-700 hover:bg-blue-800 text-white font-medium py-2 px-4 rounded-md transition-colors"
          >
            <DownloadIcon size={18} />
            <span>Download PDF</span>
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-blue-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">Lecturer</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">Expertise</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">Course</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">Room</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">Type</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">Time Slot</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">Notes</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {sortedSchedule.length > 0 ? (
                sortedSchedule.map((schedule) => (
                  <tr key={schedule._id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{schedule.lecturer.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{schedule.lecturer.expertise}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{getCourseName(schedule.courseId)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{getRoomName(schedule.roomId)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{schedule.type}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{schedule.timeSlot}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{schedule.notes || '-'}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="7" className="px-6 py-4 text-center text-sm text-gray-500">No schedules available.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default TimetableView;*/
import React, { useState, useEffect } from 'react';
import { DownloadIcon, FilterIcon } from 'lucide-react';
import jsPDF from 'jspdf';

const mockCourses = [
  { id: 'PSY101', name: 'Intro to Psychology' },
  { id: 'PSY202', name: 'Cognitive Behavior' },
  { id: 'PSY301', name: 'Behavioral Neuroscience' },
];

const mockRooms = [
  { id: 'A101', name: 'Room A101' },
  { id: 'B202', name: 'Room B202' },
  { id: 'C303', name: 'Room C303' },
];

const TimetableView = ({ lecturerId }) => {
  const [assignments, setAssignments] = useState([]);
  const [dayFilter, setDayFilter] = useState('all');
  const [courseFilter, setCourseFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');

  useEffect(() => {
    const mockSchedule = [
      {
        _id: '1',
        lecturer: { name: 'Prof. Sofia Alvarez', expertise: 'Psychology' },
        day: 'Monday',
        courseId: 'PSY101',
        timeSlot: '10:00 AM - 12:00 PM',
        startTime: '10:00 AM',
        endTime: '12:00 PM',
        roomId: 'A101',
        type: 'Lecture',
        notes: 'Bring case studies',
      },
      {
        _id: '2',
        lecturer: { name: 'Prof. Sofia Alvarez', expertise: 'Psychology' },
        day: 'Wednesday',
        courseId: 'PSY202',
        timeSlot: '1:00 PM - 3:00 PM',
        startTime: '1:00 PM',
        endTime: '3:00 PM',
        roomId: 'B202',
        type: 'Seminar',
        notes: '',
      },
      {
        _id: '3',
        lecturer: { name: 'Prof. Sofia Alvarez', expertise: 'Psychology' },
        day: 'Friday',
        courseId: 'PSY301',
        timeSlot: '9:00 AM - 11:00 AM',
        startTime: '9:00 AM',
        endTime: '11:00 AM',
        roomId: 'C303',
        type: 'Lecture',
        notes: '',
      },
      {
        _id: '4',
        lecturer: { name: 'Prof. Sofia Alvarez', expertise: 'Psychology' },
        day: 'Tuesday',
        courseId: 'PSY101',
        timeSlot: '2:00 PM - 4:00 PM',
        startTime: '2:00 PM',
        endTime: '4:00 PM',
        roomId: 'A101',
        type: 'Lab',
        notes: 'Bring lab reports',
      },
      {
        _id: '5',
        lecturer: { name: 'Prof. Sofia Alvarez', expertise: 'Psychology' },
        day: 'Thursday',
        courseId: 'PSY202',
        timeSlot: '11:00 AM - 1:00 PM',
        startTime: '11:00 AM',
        endTime: '1:00 PM',
        roomId: 'B202',
        type: 'Seminar',
        notes: 'Group presentations',
      },
      {
        _id: '6',
        lecturer: { name: 'Prof. Sofia Alvarez', expertise: 'Psychology' },
        day: 'Monday',
        courseId: 'PSY301',
        timeSlot: '3:00 PM - 5:00 PM',
        startTime: '3:00 PM',
        endTime: '5:00 PM',
        roomId: 'C303',
        type: 'Lab',
        notes: '',
      },
      {
        _id: '7',
        lecturer: { name: 'Prof. Sofia Alvarez', expertise: 'Psychology' },
        day: 'Wednesday',
        courseId: 'PSY101',
        timeSlot: '9:00 AM - 10:30 AM',
        startTime: '9:00 AM',
        endTime: '10:30 AM',
        roomId: 'A101',
        type: 'Lecture',
        notes: 'Quiz scheduled',
      },
      {
        _id: '8',
        lecturer: { name: 'Prof. Sofia Alvarez', expertise: 'Psychology' },
        day: 'Friday',
        courseId: 'PSY202',
        timeSlot: '2:00 PM - 4:00 PM',
        startTime: '2:00 PM',
        endTime: '4:00 PM',
        roomId: 'B202',
        type: 'Seminar',
        notes: '',
      },
    ];

    setAssignments(mockSchedule);
  }, []);

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  const types = ['Lecture', 'Lab', 'Seminar'];

  const filteredSchedule = assignments.filter((item) => {
    const matchesDay = dayFilter === 'all' || item.day === dayFilter;
    const matchesCourse = courseFilter === 'all' || item.courseId === courseFilter;
    const matchesType = typeFilter === 'all' || item.type === typeFilter;
    return matchesDay && matchesCourse && matchesType;
  });

  const getCourseName = (courseId) => {
    const course = mockCourses.find((c) => c.id === courseId);
    return course ? course.name : 'Unknown';
  };

  const getRoomName = (roomId) => {
    const room = mockRooms.find((r) => r.id === roomId);
    return room ? room.name : 'Unknown';
  };

  const downloadPDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(18);
    doc.text('Lecturer Timetable Schedule', 14, 22);
    doc.setFontSize(12);
    doc.text(`Lecturer ID: ${lecturerId}`, 14, 32);
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 14, 38);

    let yPos = 50;
    doc.setFont(undefined, 'bold');
    doc.text('Course', 14, yPos);
    doc.text('Day', 80, yPos);
    doc.text('Time', 110, yPos);
    doc.text('Room', 150, yPos);
    doc.text('Type', 180, yPos);
    doc.setFont(undefined, 'normal');
    yPos += 10;

    filteredSchedule.forEach((item) => {
      if (yPos > 270) {
        doc.addPage();
        yPos = 20;
      }
      doc.text(getCourseName(item.courseId), 14, yPos);
      doc.text(item.day, 80, yPos);
      doc.text(`${item.startTime}-${item.endTime}`, 110, yPos);
      doc.text(getRoomName(item.roomId), 150, yPos);
      doc.text(item.type, 180, yPos);
      yPos += 10;
    });

    doc.save('lecturer-timetable.pdf');
  };

  return (
    <div className="p-4">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">My Timetable</h2>
          <p className="text-gray-600">View your weekly teaching schedule</p>
        </div>
        <div className="flex items-center space-x-3 mt-4 md:mt-0">
          {[{ label: 'Day', options: days, value: dayFilter, setter: setDayFilter },
            { label: 'Course', options: mockCourses.map(c => ({ id: c.id, name: c.name })), value: courseFilter, setter: setCourseFilter },
            { label: 'Type', options: types, value: typeFilter, setter: setTypeFilter }]
            .map(({ label, options, value, setter }, index) => (
              <div className="relative" key={index}>
                <select
                  className="appearance-none bg-white border border-gray-300 rounded-md pl-10 pr-4 py-2 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={value}
                  onChange={(e) => setter(e.target.value)}
                >
                  <option value="all">All {label}s</option>
                  {options.map((opt) => (
                    <option key={opt.id || opt} value={opt.id || opt}>
                      {opt.name || opt}
                    </option>
                  ))}
                </select>
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center px-3 text-gray-500">
                  <FilterIcon size={16} />
                </div>
              </div>
            ))}
          <button
            onClick={downloadPDF}
            className="flex items-center space-x-2 bg-blue-700 hover:bg-blue-800 text-white font-medium py-2 px-4 rounded-md transition-colors"
          >
            <DownloadIcon size={18} />
            <span>Download PDF</span>
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-blue-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">Lecturer</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">Expertise</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">Time Slot</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">Notes</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredSchedule.length > 0 ? (
                filteredSchedule.map((schedule) => (
                  <tr key={schedule._id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{schedule.lecturer.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{schedule.lecturer.expertise}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{schedule.timeSlot}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{schedule.notes}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="4" className="px-6 py-4 text-center text-sm text-gray-500">No schedules available.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default TimetableView;


