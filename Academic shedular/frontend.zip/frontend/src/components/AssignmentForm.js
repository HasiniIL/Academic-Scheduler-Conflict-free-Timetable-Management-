/*
import React from 'react';
import { EditIcon, TrashIcon, AlertCircleIcon } from 'lucide-react';

export const ScheduleTable = ({
  assignments,
  onEdit,
  onDeleteRequest,
  lecturers,
}) => {
  // Function to get lecturer name
  const getLecturerName = (lecturerId) => {
    const lecturer = lecturers.find((l) => l._id === lecturerId);
    return lecturer ? lecturer.name : 'Unknown';
  };

  // Function to get lecturer expertise
  const getLecturerExpertise = (lecturerId) => {
    const lecturer = lecturers.find((l) => l._id === lecturerId);
    return lecturer ? lecturer.expertise : 'Unknown Expertise';
  };

  const getTimeSlot = (timeSlot) => {
    return timeSlot ? `${timeSlot.day} ${timeSlot.startTime} - ${timeSlot.endTime}` : 'Unknown';
  };

  return (
    <div className="overflow-x-auto">
      {assignments.length > 0 ? (
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-blue-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-blue-600 uppercase tracking-wider">Lecturer</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-blue-600 uppercase tracking-wider">Expertise</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-blue-600 uppercase tracking-wider">Time Slot</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-blue-600 uppercase tracking-wider">Notes</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-blue-600 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {assignments.map((assignment) => (
              <tr key={assignment._id} className="hover:bg-blue-50 transition-colors duration-150">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="h-8 w-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mr-3">
                      <span className="font-medium text-sm">
                        {getLecturerName(assignment.lecturer)?.charAt(0)}
                      </span>
                    </div>
                    <div className="text-sm font-medium text-gray-900">
                      {getLecturerName(assignment.lecturer)}
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {getLecturerExpertise(assignment.lecturer)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {getTimeSlot(assignment.timeSlot)}
                </td>
                <td className="px-6 py-4 text-sm text-gray-500 max-w-xs truncate">
                  {assignment.notes || '-'}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <button
                    onClick={() => onEdit(assignment)}
                    className="inline-flex items-center text-blue-600 hover:text-blue-800 mr-4"
                  >
                    <EditIcon className="h-4 w-4" />
                    <span className="ml-2">Edit</span>
                  </button>
                  <button
                    onClick={() => onDeleteRequest(assignment._id)}
                    className="inline-flex items-center text-red-600 hover:text-red-800"
                  >
                    <TrashIcon className="h-4 w-4" />
                    <span className="ml-2">Delete</span>
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <div className="flex flex-col items-center justify-center py-12 text-gray-500">
          <AlertCircleIcon className="h-12 w-12 mb-4 text-blue-400" />
          <h3 className="text-lg font-medium mb-1">No assignments found</h3>
          <p className="text-sm">Create a new assignment to get started.</p>
        </div>
      )}
    </div>
  );
};
*/

import React, { useState } from 'react';

export const AssignmentForm = ({ lecturers, initialData, onSubmit }) => {
  const [lecturer, setLecturer] = useState(initialData?.lecturer || '');
  const [timeSlot, setTimeSlot] = useState(initialData?.timeSlot || {
    day: '',
    startTime: '',
    endTime: ''
  });
  const [notes, setNotes] = useState(initialData?.notes || '');

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!lecturer || !timeSlot.day || !timeSlot.startTime || !timeSlot.endTime) {
      alert('Please fill in all required fields.');
      return;
    }

    const formData = {
      lecturer,
      timeSlot,
      notes
    };

    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
     {/* Form fields (same as before) */}
      <div>
        <label className="block text-sm font-medium text-gray-700">Lecturer</label>
        <select
          className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
          value={lecturer}
          onChange={(e) => setLecturer(e.target.value)}
        >
          <option value="">Select a lecturer</option>
          {lecturers.map((l) => (
            <option key={l._id} value={l._id}>{l.name}</option>
          ))}
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Day</label>
        <input
          type="text"
          value={timeSlot.day}
          onChange={(e) => setTimeSlot({ ...timeSlot, day: e.target.value })}
          className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
          placeholder="e.g., Monday"
        />
      </div>

      <div className="flex space-x-4">
        <div className="flex-1">
          <label className="block text-sm font-medium text-gray-700">Start Time</label>
          <input
            type="time"
            value={timeSlot.startTime}
            onChange={(e) => setTimeSlot({ ...timeSlot, startTime: e.target.value })}
            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
          />
        </div>
        <div className="flex-1">
          <label className="block text-sm font-medium text-gray-700">End Time</label>
          <input
            type="time"
            value={timeSlot.endTime}
            onChange={(e) => setTimeSlot({ ...timeSlot, endTime: e.target.value })}
            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Notes (optional)</label>
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
          rows="3"
          placeholder="Additional details..."
        ></textarea>
      </div>

      <div className="text-right">
        <button
          type="submit"
          className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
        >
          {initialData ? 'Update Assignment' : 'Create Assignment'}
        </button>
      </div>
    </form>
  );
};