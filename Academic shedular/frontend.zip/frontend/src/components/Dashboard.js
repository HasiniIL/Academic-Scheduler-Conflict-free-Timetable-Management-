//befor login
/*
import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { UsersIcon, CalendarIcon, BookOpenIcon, CheckCircleIcon, EditIcon, ClipboardListIcon } from 'lucide-react';
import axios from 'axios';

export const Dashboard = () => {
  const navigate = useNavigate();
  const [lecturers, setLecturers] = useState([]);
  const [courses, setCourses] = useState([]);

  useEffect(() => {
    const fetchLecturers = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/lecturers');
        setLecturers(response.data);
      } catch (error) {
        console.error('Error fetching lecturers:', error);
      }
    };

    const fetchCourses = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/courses');
        setCourses(response.data);
      } catch (error) {
        console.error('Error fetching courses:', error);
      }
    };

    fetchLecturers();
    fetchCourses();
  }, []);

  const handleLogout = () => {
    navigate('/lecturer-dashboard');
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-end mb-6">
        <button
          onClick={handleLogout}
          className="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600 transition-colors"
        >
          Logout
        </button>
      </div>

      <h1 className="text-3xl font-bold text-gray-800 mb-8">Admin Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Link to="/lecturers" className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <UsersIcon className="h-8 w-8 text-red-500" />
            <span className="text-2xl font-bold text-gray-800">{lecturers.length}</span>
          </div>
          <h2 className="text-lg font-bold text-gray-800">Lecturers</h2>
          <p className="text-gray-600 mt-2">Manage faculty members and their details</p>
        </Link>

        <Link to="/schedule" className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <CalendarIcon className="h-8 w-8 text-red-500" />
            <span className="text-2xl font-bold text-gray-800">Schedule</span>
          </div>
          <h2 className="text-lg font-bold text-gray-800">Class Schedule</h2>
          <p className="text-gray-600 mt-2">Manage course assignments and schedules</p>
        </Link>

        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <BookOpenIcon className="h-8 w-8 text-red-600" />
            <span className="text-2xl font-bold text-gray-800">{courses.length}</span>
          </div>
          <h2 className="text-lg font-bold text-gray-800">Courses</h2>
          <p className="text-gray-600 mt-2">Total available courses in the system</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
        <Link to="/lecturer-availability" className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <CheckCircleIcon className="h-8 w-8 text-red-500" />
            <span className="text-2xl font-bold text-gray-800">{lecturers.length}</span>
          </div>
          <h2 className="text-lg font-bold text-gray-800">Lecturer Availability</h2>
          <p className="text-gray-600 mt-2">View and manage lecturer availability</p>
        </Link>

        <Link to="/lecture-requests" className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <ClipboardListIcon className="h-8 w-8 text-red-500" />
            <span className="text-2xl font-bold text-gray-800">Requests</span>
          </div>
          <h2 className="text-lg font-bold text-gray-800">Lecture Requests</h2>
          <p className="text-gray-600 mt-2">Manage lecture requests from students</p>
        </Link>
      </div>
    </div>
  );
};*/
import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  UsersIcon,
  CalendarIcon,
  BookOpenIcon,
  CheckCircleIcon,
  ClipboardListIcon,
} from 'lucide-react';
import axios from 'axios';

export const Dashboard = () => {
  const navigate = useNavigate();
  const [lecturers, setLecturers] = useState([]);
  const [courses, setCourses] = useState([]);

  useEffect(() => {
    const fetchLecturers = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/lecturers');
        setLecturers(response.data);
      } catch (error) {
        console.error('Error fetching lecturers:', error);
      }
    };

    const fetchCourses = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/courses');
        setCourses(response.data);
      } catch (error) {
        console.error('Error fetching courses:', error);
      }
    };

    fetchLecturers();
    fetchCourses();
  }, []);

  const handleLogout = () => {
    // Clear localStorage or session (optional, based on your auth implementation)
    localStorage.removeItem('token'); // assuming you're storing JWT
    navigate('/lecturer-login'); // redirect to login page
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-end mb-6">
        <button
          onClick={handleLogout}
          className="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600 transition-colors"
        >
          Logout
        </button>
      </div>

      <h1 className="text-3xl font-bold text-gray-800 mb-8">Lecturer Scheduling Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Link to="/lecturers" className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <UsersIcon className="h-8 w-8 text-red-500" />
            <span className="text-2xl font-bold text-gray-800">{lecturers.length}</span>
          </div>
          <h2 className="text-lg font-bold text-gray-800">Lecturers</h2>
          <p className="text-gray-600 mt-2">Manage faculty members and their details</p>
        </Link>

        <Link to="/schedule" className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <CalendarIcon className="h-8 w-8 text-red-500" />
            <span className="text-2xl font-bold text-gray-800">Schedule</span>
          </div>
          <h2 className="text-lg font-bold text-gray-800">Class Schedule</h2>
          <p className="text-gray-600 mt-2">Manage course assignments and schedules</p>
        </Link>

        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <BookOpenIcon className="h-8 w-8 text-red-600" />
            <span className="text-2xl font-bold text-gray-800">{courses.length}</span>
          </div>
          <h2 className="text-lg font-bold text-gray-800">Courses</h2>
          <p className="text-gray-600 mt-2">Total available courses in the system</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
        <Link to="/lecturer-availability" className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <CheckCircleIcon className="h-8 w-8 text-red-500" />
            <span className="text-2xl font-bold text-gray-800">{lecturers.length}</span>
          </div>
          <h2 className="text-lg font-bold text-gray-800">Lecturer Availability</h2>
          <p className="text-gray-600 mt-2">View and manage lecturer availability</p>
        </Link>

        <Link to="/lecture-requests" className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <ClipboardListIcon className="h-8 w-8 text-red-500" />
            <span className="text-2xl font-bold text-gray-800">Requests</span>
          </div>
          <h2 className="text-lg font-bold text-gray-800">Lecture Requests</h2>
          <p className="text-gray-600 mt-2">Manage lecture requests from students</p>
        </Link>
      </div>
    </div>
  );
};

