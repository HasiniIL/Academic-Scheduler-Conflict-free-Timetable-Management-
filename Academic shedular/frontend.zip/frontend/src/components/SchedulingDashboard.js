
/*
import React, { useState, useEffect } from 'react';
import { PlusIcon, XIcon, UsersIcon } from 'lucide-react';
import axios from 'axios';
import { AssignmentForm } from './AssignmentForm';
import { ScheduleTable } from './ScheduleTable';

const API_URL = 'http://localhost:5000/api/schedules';
const LECTURERS_API = 'http://localhost:5000/api/lecturers';

export const SchedulingDashboard = () => {
  const [assignments, setAssignments] = useState([]);
  const [lecturers, setLecturers] = useState([]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingAssignment, setEditingAssignment] = useState(null);
  const [filterLecturer, setFilterLecturer] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [schedulesRes, lecturersRes] = await Promise.all([
          axios.get(API_URL),
          axios.get(LECTURERS_API)
        ]);
        setAssignments(schedulesRes.data);
        setLecturers(lecturersRes.data);
      } catch (err) {
        console.error('Error fetching data:', err);
        alert('Error loading data');
      }
    };
    fetchData();
  }, []);

  const handleEdit = (assignment) => {
    setEditingAssignment(assignment);
    setIsFormOpen(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this assignment?')) {
      try {
        await axios.delete(`${API_URL}/${id}`);
        setAssignments(prev => prev.filter(a => a._id !== id));
        alert('Assignment deleted successfully');
      } catch (err) {
        console.error('Error deleting assignment:', err);
        alert('Error deleting assignment');
      }
    }
  };

  const handleFormSubmit = async (formData) => {
    try {
      if (editingAssignment) {
        await axios.put(`${API_URL}/${editingAssignment._id}`, formData);
        const updated = await axios.get(API_URL);
        setAssignments(updated.data);
      } else {
        const res = await axios.post(API_URL, formData);
        setAssignments(prev => [...prev, res.data]);
      }
      setIsFormOpen(false);
      setEditingAssignment(null);
    } catch (err) {
      console.error('Error saving assignment:', err);
      alert('Error saving assignment');
    }
  };

  const filteredAssignments = filterLecturer
    ? assignments.filter(a => a.lecturer._id === filterLecturer) // Fixed lecturer comparison
    : assignments;

  return (
    <div className="container mx-auto px-4 py-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800">Faculty Scheduling System</h1>
        <p className="text-gray-600 mt-2">Manage lecturer assignments to courses and time slots</p>
      </header>

      <div className="flex justify-between items-center mb-6 flex-wrap gap-4">
        <div className="flex flex-wrap gap-4">
          <button
            onClick={() => setFilterLecturer('')}
            className="bg-blue-600 text-white px-4 py-2 rounded-md flex items-center" // Green button for Show All Assignments
          >
            <UsersIcon className="h-4 w-4 mr-2" />
            Show All Assignments
          </button>
        </div>

        <div className="flex flex-wrap gap-4">
          <div className="relative">
            <select
              className="bg-white border border-gray-300 rounded-md py-2 pl-3 pr-10 text-sm"
              value={filterLecturer}
              onChange={(e) => setFilterLecturer(e.target.value)}
            >
              <option value="">Filter by Lecturer</option>
              {lecturers.map((lecturer) => (
                <option key={lecturer._id} value={lecturer._id}>
                  {lecturer.name}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={() => setIsFormOpen(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md flex items-center"
          >
            <PlusIcon className="h-4 w-4 mr-2" />
            New Assignment
          </button>
        </div>
      </div>

      <ScheduleTable
        assignments={filteredAssignments}
        lecturers={lecturers}
        onEdit={handleEdit}
        onDeleteRequest={handleDelete}
      />

      {isFormOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg w-full max-w-xl">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">
                {editingAssignment ? 'Edit Assignment' : 'New Assignment'}
              </h2>
              <button
                onClick={() => {
                  setIsFormOpen(false);
                  setEditingAssignment(null);
                }}
                className="text-gray-500 hover:text-gray-700"
              >
                <XIcon className="h-5 w-5" />
              </button>
            </div>
            <AssignmentForm
              lecturers={lecturers}
              initialData={editingAssignment}
              onSubmit={handleFormSubmit}
            />
          </div>
        </div>
      )}
    </div>
  );
};
*/

import React, { useState, useEffect } from 'react';
import { PlusIcon, XIcon, UsersIcon } from 'lucide-react';
import axios from 'axios';
import { AssignmentForm } from './AssignmentForm';
import { ScheduleTable } from './ScheduleTable';

const API_URL = 'http://localhost:5000/api/schedules';
const LECTURERS_API = 'http://localhost:5000/api/lecturers';

export const SchedulingDashboard = () => {
  const [assignments, setAssignments] = useState([]);
  const [lecturers, setLecturers] = useState([]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingAssignment, setEditingAssignment] = useState(null);
  const [filterLecturer, setFilterLecturer] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [schedulesRes, lecturersRes] = await Promise.all([
          axios.get(API_URL),
          axios.get(LECTURERS_API)
        ]);
        setAssignments(schedulesRes.data);
        setLecturers(lecturersRes.data);
      } catch (err) {
        console.error('Error fetching data:', err);
        alert('Error loading data');
      }
    };
    fetchData();
  }, []);

  const handleEdit = (assignment) => {
    setEditingAssignment(assignment);
    setIsFormOpen(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this assignment?')) {
      try {
        await axios.delete(`${API_URL}/${id}`);
        setAssignments(prev => prev.filter(a => a._id !== id));
        alert('Assignment deleted successfully');
      } catch (err) {
        console.error('Error deleting assignment:', err);
        alert('Error deleting assignment');
      }
    }
  };

  const handleFormSubmit = async (formData) => {
    try {
      if (editingAssignment) {
        await axios.put(`${API_URL}/${editingAssignment._id}`, formData);
        const updated = await axios.get(API_URL);
        setAssignments(updated.data);
      } else {
        const res = await axios.post(API_URL, formData);
        setAssignments(prev => [...prev, res.data]);
      }
      setIsFormOpen(false);
      setEditingAssignment(null);
    } catch (err) {
      console.error('Error saving assignment:', err);
      alert('Error saving assignment');
    }
  };

  const filteredAssignments = filterLecturer
    ? assignments.filter(a => a.lecturer._id === filterLecturer)
    : assignments;

  return (
    <div className="container mx-auto px-4 py-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800">Faculty Scheduling System</h1>
        <p className="text-gray-600 mt-2">Manage lecturer assignments to courses and time slots</p>
      </header>

      <div className="flex justify-between items-center mb-6 flex-wrap gap-4">
        <div className="flex flex-wrap gap-4">
          <button
            onClick={() => setFilterLecturer('')}
            className="bg-blue-600 text-white px-4 py-2 rounded-md flex items-center"
          >
            <UsersIcon className="h-4 w-4 mr-2" />
            Show All Assignments
          </button>
          <button
            onClick={() => setFilterLecturer('')}
            className="bg-green-600 text-white px-4 py-2 rounded-md flex items-center"
          >
            <UsersIcon className="h-4 w-4 mr-2" />
         All Lecturers
          </button>
        </div>

        <div className="flex flex-wrap gap-4">
          <div className="relative">
            <select
              className="bg-white border border-gray-300 rounded-md py-2 pl-3 pr-10 text-sm"
              value={filterLecturer}
              onChange={(e) => setFilterLecturer(e.target.value)}
            >
              <option value="">Filter by Lecturer</option>
              {lecturers.map((lecturer) => (
                <option key={lecturer._id} value={lecturer._id}>
                  {lecturer.name}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={() => setIsFormOpen(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md flex items-center"
          >
            <PlusIcon className="h-4 w-4 mr-2" />
            New Assignment
          </button>
        </div>
      </div>

      <ScheduleTable
        assignments={filteredAssignments}
        lecturers={lecturers}
        onEdit={handleEdit}
        onDeleteRequest={handleDelete}
      />

      {isFormOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg w-full max-w-xl">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">
                {editingAssignment ? 'Edit Assignment' : 'New Assignment'}
              </h2>
              <button
                onClick={() => {
                  setIsFormOpen(false);
                  setEditingAssignment(null);
                }}
                className="text-gray-500 hover:text-gray-700"
              >
                <XIcon className="h-5 w-5" />
              </button>
            </div>
            <AssignmentForm
              lecturers={lecturers}
              initialData={editingAssignment}
              onSubmit={handleFormSubmit}
            />
          </div>
        </div>
      )}
    </div>
  );
};
