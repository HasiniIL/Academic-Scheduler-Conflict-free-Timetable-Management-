/*import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { LockIcon, UserIcon, ShieldIcon } from "lucide-react";

export function LecturerLogin() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);

    try {
      const response = await fetch("http://localhost:5000/api/lecturers/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Login failed");
      }

      // Store token and lecturer info in localStorage or context
      localStorage.setItem("lecturerToken", data.token);
      localStorage.setItem("lecturerInfo", JSON.stringify(data.lecturer));

      navigate("/lecturer-dashboard");
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="min-h-screen w-full bg-blue-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md overflow-hidden rounded-lg shadow-lg">
        <div className="bg-blue-600 p-6 text-white text-center">
          <div className="flex justify-center mb-2">
            <ShieldIcon size={40} />
          </div>
          <h1 className="text-2xl font-bold">Lecturer Portal</h1>
          <p className="text-blue-100">Sign in to your account</p>
        </div>

        <div className="bg-white p-8">
          {error && (
            <div className="mb-4 text-red-500 text-sm font-medium">{error}</div>
          )}
          <form onSubmit={handleSubmit}>
          
            <div className="mb-6">
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                Email Address
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                  <UserIcon size={18} className="text-gray-400" />
                </div>
                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full py-3 pl-10 pr-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="lecturer@example.com"
                  required
                />
              </div>
            </div>

        
            <div className="mb-6">
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                  <LockIcon size={18} className="text-gray-400" />
                </div>
                <input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full py-3 pl-10 pr-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="••••••••"
                  required
                />
              </div>
            </div>

       
            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-3 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              Sign In
            </button>
          </form>

          <div className="mt-6 text-center text-sm text-gray-500">
            <p>Protected Lecturer Area</p>
          </div>
        </div>
      </div>
    </div>
  );
}
*/
// ./components/loginpage.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const LecturerLogin = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();

    // ✅ Hardcoded credentials
    const allowedEmail = 'sofia@university.com';
    const allowedPassword = 'password123';

    if (email === allowedEmail && password === allowedPassword) {
      const fakeLecturer = {
        name: 'Prof. Sofia Alvarez',
        email: allowedEmail,
        department: 'Psychology',
        _id: '12345',
      };

      localStorage.setItem('lecturerInfo', JSON.stringify(fakeLecturer));
      navigate('/lecturer-dashboard');
    } else {
      setError('Invalid credentials');
    }
  };

  return (
    <div className="flex items-center justify-center h-screen bg-gray-100">
      <form
        onSubmit={handleLogin}
        className="bg-white p-8 rounded shadow-md w-full max-w-md"
      >
        <h2 className="text-2xl font-bold mb-6 text-center">Lecturer Login</h2>
        {error && <p className="text-red-500 mb-4">{error}</p>}
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full mb-4 p-2 border border-gray-300 rounded"
          required
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full mb-6 p-2 border border-gray-300 rounded"
          required
        />
        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700"
        >
          Login
        </button>
      </form>
    </div>
  );
};

export default LecturerLogin;
