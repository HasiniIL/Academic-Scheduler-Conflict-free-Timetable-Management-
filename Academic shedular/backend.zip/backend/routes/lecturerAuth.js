const express = require('express');
const router = express.Router();
const Lecturer = require('../models/LLecturer');
const jwt = require('jsonwebtoken');

// POST /api/lecturers/login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    const lecturer = await Lecturer.findOne({ email });

    if (!lecturer) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    const isMatch = await lecturer.matchPassword(password);

    if (!isMatch) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    const token = jwt.sign({ id: lecturer._id, role: 'lecturer' }, process.env.JWT_SECRET, {
      expiresIn: '1d',
    });

    res.status(200).json({
      token,
      lecturer: {
        id: lecturer._id,
        name: lecturer.name,
        email: lecturer.email,
        department: lecturer.department,
      },
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
