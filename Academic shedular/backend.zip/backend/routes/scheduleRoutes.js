/*const express = require('express');
const router = express.Router();
const Schedule = require('../models/schedule');

// Create new schedule
router.post('/', async (req, res) => {
  try {
    const schedule = new Schedule({
      lecturer: req.body.lecturer,
      course: req.body.course,
      timeSlot: req.body.timeSlot,
      notes: req.body.notes
    });

    const savedSchedule = await schedule.save();
    res.status(201).json(savedSchedule);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Get all schedules with populated data
router.get('/', async (req, res) => {
  try {
    const schedules = await Schedule.find()
      .populate('lecturer', 'name expertise')
      .populate('course', 'name code');
    res.json(schedules);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;*/
/*
const express = require('express');
const router = express.Router();
const Schedule = require('../models/schedule');

// Create new schedule
router.post('/', async (req, res) => {
  try {
    const schedule = new Schedule({
      lecturer: req.body.lecturer,
      timeSlot: req.body.timeSlot,
      notes: req.body.notes
    });

    const savedSchedule = await schedule.save();
    res.status(201).json(savedSchedule);
  } catch (err) {
    console.error(err);
    res.status(400).json({ message: err.message });
  }
});

// Get all schedules
router.get('/', async (req, res) => {
  try {
    const schedules = await Schedule.find()
      .populate('lecturer', 'name expertise'); // Only lecturer
    res.json(schedules);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
*/
/*
const express = require('express');
const router = express.Router();
const Schedule = require('../models/schedule');

// Create new schedule
router.post('/', async (req, res) => {
  try {
    const schedule = new Schedule({
      lecturer: req.body.lecturer,
      timeSlot: req.body.timeSlot,
      notes: req.body.notes
    });

    const savedSchedule = await schedule.save();
    res.status(201).json(savedSchedule);
  } catch (err) {
    console.error(err);
    res.status(400).json({ message: err.message });
  }
});

// Get all schedules
router.get('/', async (req, res) => {
  try {
    const schedules = await Schedule.find()
      .populate('lecturer', 'name expertise'); // Only lecturer
    res.json(schedules);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// DELETE a schedule by ID
router.delete('/:id', async (req, res) => {
  try {
    const scheduleId = req.params.id;

    // Attempt to find and delete the schedule by its ID
    const deletedSchedule = await Schedule.findByIdAndDelete(scheduleId);

    // If no schedule was found with the given ID
    if (!deletedSchedule) {
      return res.status(404).json({ message: "Schedule not found" });
    }

    // Return success message
    res.status(200).json({ message: "Schedule deleted successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;*/
/*
const express = require('express');
const router = express.Router();
const Schedule = require('../models/schedule');

// Create new schedule
router.post('/', async (req, res) => {
  try {
    const schedule = new Schedule({
      lecturer: req.body.lecturer,
      timeSlot: req.body.timeSlot,
      notes: req.body.notes
    });

    const savedSchedule = await schedule.save();

    // Populate lecturer after saving
    const populatedSchedule = await Schedule.findById(savedSchedule._id)
      .populate('lecturer', 'name expertise');

    res.status(201).json(populatedSchedule);
  } catch (err) {
    console.error(err);
    res.status(400).json({ message: err.message });
  }
});

// Get all schedules
router.get('/', async (req, res) => {
  try {
    const schedules = await Schedule.find()
      .populate('lecturer', 'name expertise');
    res.json(schedules);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Update a schedule
router.put('/:id', async (req, res) => {
  try {
    const updatedSchedule = await Schedule.findByIdAndUpdate(
      req.params.id,
      {
        lecturer: req.body.lecturer,
        timeSlot: req.body.timeSlot,
        notes: req.body.notes
      },
      { new: true }
    ).populate('lecturer', 'name expertise');

    if (!updatedSchedule) {
      return res.status(404).json({ message: 'Schedule not found' });
    }

    res.json(updatedSchedule);
  } catch (err) {
    console.error(err);
    res.status(400).json({ message: 'Update failed' });
  }
});

// DELETE a schedule by ID
router.delete('/:id', async (req, res) => {
  try {
    const scheduleId = req.params.id;

    const deletedSchedule = await Schedule.findByIdAndDelete(scheduleId);

    if (!deletedSchedule) {
      return res.status(404).json({ message: "Schedule not found" });
    }

    res.status(200).json({ message: "Schedule deleted successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
*/
const express = require('express');
const router = express.Router();
const Schedule = require('../models/schedule');

// Create new schedule
router.post('/', async (req, res) => {
  try {
    const schedule = new Schedule({
      lecturer: req.body.lecturer,
      timeSlot: req.body.timeSlot,
      notes: req.body.notes
    });

    const savedSchedule = await schedule.save();

    // Populate lecturer after saving
    const populatedSchedule = await Schedule.findById(savedSchedule._id)
      .populate('lecturer', 'name expertise');

    res.status(201).json(populatedSchedule);
  } catch (err) {
    console.error(err);
    res.status(400).json({ message: err.message });
  }
});

// Get all schedules
router.get('/', async (req, res) => {
  try {
    const schedules = await Schedule.find()
      .populate('lecturer', 'name expertise');
    res.json(schedules);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Get schedules for a specific lecturer
router.get('/lecturer/:lecturerId', async (req, res) => {
  const { lecturerId } = req.params;
  try {
    const schedules = await Schedule.find({ lecturer: lecturerId })
      .populate('lecturer', 'name expertise');
    
    if (schedules.length === 0) {
      return res.status(404).json({ message: 'No schedules found for this lecturer' });
    }

    res.json(schedules);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Update a schedule
router.put('/:id', async (req, res) => {
  try {
    const updatedSchedule = await Schedule.findByIdAndUpdate(
      req.params.id,
      {
        lecturer: req.body.lecturer,
        timeSlot: req.body.timeSlot,
        notes: req.body.notes
      },
      { new: true }
    ).populate('lecturer', 'name expertise');

    if (!updatedSchedule) {
      return res.status(404).json({ message: 'Schedule not found' });
    }

    res.json(updatedSchedule);
  } catch (err) {
    console.error(err);
    res.status(400).json({ message: 'Update failed' });
  }
});

// DELETE a schedule by ID
router.delete('/:id', async (req, res) => {
  try {
    const scheduleId = req.params.id;

    const deletedSchedule = await Schedule.findByIdAndDelete(scheduleId);

    if (!deletedSchedule) {
      return res.status(404).json({ message: "Schedule not found" });
    }

    res.status(200).json({ message: "Schedule deleted successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
