
/*
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
require('dotenv').config();

// Import route modules
const lecturerRoutes = require('./routes/lecturerRoutes');
const scheduleRoutes = require('./routes/scheduleRoutes');
const availabilityRoutes = require('./routes/availabilityRoutes');

const app = express();
const PORT = process.env.PORT || 5000;  // Port number (either from environment variable or default to 5000)

// Middleware
app.use(cors());  // Enable Cross-Origin Resource Sharing
app.use(bodyParser.json());  // Parse incoming JSON data

// Use routes
app.use('/api/lecturers', lecturerRoutes);
app.use('/api/schedules', scheduleRoutes);
app.use('/api/availability', availabilityRoutes);

// Connect to MongoDB
mongoose
  .connect(process.env.MONGO_URI)  // MongoDB URI from .env
  .then(() => console.log('MongoDB connected'))  // Success message
  .catch((err) => console.error('MongoDB connection error:', err));  // Error message

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

/*
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const connection = mongoose.connection;
connection.once('open', () => {
  console.log('MongoDB database connection established successfully');
});

// Your existing routes
const lecturerRoutes = require('./routes/lecturers');
const scheduleRoutes = require('./routes/schedules');
const availabilityRoutes = require('./routes/availability');

app.use('/api/lecturers', lecturerRoutes);
app.use('/api/schedules', scheduleRoutes);
app.use('/api/availability', availabilityRoutes);

// ✅ Temporary mock route to fix React 404 error
app.get('/api/courses', (req, res) => {
  res.json([]); // Send back empty course list temporarily
});

// Default route
app.get('/', (req, res) => {
  res.send('API is running...');
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});*/


//before update login page
// server.js
/*
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
require('dotenv').config();

const lecturerRoutes = require('./routes/lecturerRoutes');
const scheduleRoutes = require('./routes/scheduleRoutes');
const availabilityRoutes = require('./routes/availabilityRoutes');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());  // Enable Cross-Origin Resource Sharing
app.use(bodyParser.json());  // Parse incoming JSON data

// Routes
app.use('/api/lecturers', lecturerRoutes);
app.use('/api/schedules', scheduleRoutes);
app.use('/api/availability', availabilityRoutes);

// MongoDB connection
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log('MongoDB connected'))
  .catch((err) => console.error('MongoDB connection error:', err));

// Server listen
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});*/
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
require('dotenv').config();

const lecturerRoutes = require('./routes/lecturerRoutes');     // Admin CRUD for lecturers
const lecturerAuthRoutes = require('./routes/lecturerAuth');   // Lecturer login
const scheduleRoutes = require('./routes/scheduleRoutes');
const availabilityRoutes = require('./routes/availabilityRoutes');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Routes
app.use('/api/lecturers', lecturerRoutes);         // e.g. GET/POST lecturers by admin
app.use('/api/lecturers', lecturerAuthRoutes);     // e.g. POST /login for lecturers
app.use('/api/schedules', scheduleRoutes);
app.use('/api/availability', availabilityRoutes);

// MongoDB connection
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('MongoDB connected'))
  .catch((err) => console.error('MongoDB connection error:', err));

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

